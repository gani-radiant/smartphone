"""smartphone_user_verifications URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from user import views as user_views

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url('^$',user_views.index,name="index"),
    url('user/register', user_views.register, name="register"),
    url('user/userpage',user_views.userpage,name="userpage"),
    url('user/mydetails',user_views.mydetails,name="mydetails"),
    url('user/dataset',user_views.dataset,name="dataset"),
    url('user/security_non_intrusive',user_views.security_non_intrusive,name="security_non_intrusive"),
    url('user/security_intrusive',user_views.security_intrusive,name="security_intrusive"),
    url('categoryanalysis/(?P<chart_type>\w+)',user_views.categoryanalysis_chart,name="categoryanalysis_chart"),
]
