from django.db import models

# Create your models here.
class RegisterModel(models.Model):
    firstname=models.CharField(max_length=300)
    lastname=models.CharField(max_length=200)
    userid=models.CharField(max_length=200)
    password=models.IntegerField()
    mblenum=models.BigIntegerField()
    email=models.EmailField(max_length=400)
    gender=models.CharField(max_length=200)


class NonintrusiveModel(models.Model):
    name=models.CharField(max_length=200)
    mailid=models.EmailField(max_length=200)
    phone_num = models.BigIntegerField()
    gen = models.CharField(max_length=100)
    usid = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    starting_time = models.CharField(max_length=100)
    ending_time = models.CharField(max_length=100)
    difference_time = models.CharField(max_length=100)
    total_mins = models.IntegerField()

class NonintrusiveModels(models.Model):
    name=models.CharField(max_length=200)
    mailid=models.EmailField(max_length=200)
    phone_num = models.BigIntegerField()
    gen = models.CharField(max_length=100)
    usid = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    starting_time = models.CharField(max_length=100)
    ending_time = models.CharField(max_length=100)
    difference_time = models.CharField(max_length=100)
    total_mins = models.IntegerField()