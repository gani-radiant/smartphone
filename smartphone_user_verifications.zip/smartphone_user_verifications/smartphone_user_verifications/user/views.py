from django.db.models import Avg
from django.shortcuts import render, redirect

# Create your views here.
from user.forms import RegisterForms
from user.models import RegisterModel, NonintrusiveModel, NonintrusiveModels


def index(request):
    if request.method=="POST":
        usid=request.POST.get('username')
        pswd = request.POST.get('password')
        try:
            check = RegisterModel.objects.get(userid=usid,password=pswd)
            request.session['userid']=check.id
            return redirect('userpage')
        except:
            pass
    return render(request,'user/index.html')

def register(request):
    if request.method=="POST":
        forms=RegisterForms(request.POST)
        if forms.is_valid():
            forms.save()
            return redirect('index')
    else:
        forms=RegisterForms()
    return render(request,'user/register.html',{'form':forms})

def userpage(request):
    return render(request,'user/userpage.html')

def mydetails(request):
    usid = request.session['userid']
    us_id = RegisterModel.objects.get(id=usid)
    return render(request,'user/mydetails.html',{'obje':us_id})

def dataset(request):
    obj = NonintrusiveModel.objects.all()
    return render(request,'user/dataset.html',{'objects':obj})

def security_non_intrusive(request):
    obj = NonintrusiveModel.objects.filter(status="security non intrusive user")
    return render(request,'user/security_non_intrusive.html',{'objects':obj})

def security_intrusive(request):
    obj = NonintrusiveModel.objects.filter(status="security intrusive user")
    return render(request,'user/security_intrusive.html',{'objects':obj})

def categoryanalysis_chart(request,chart_type):
    chart = NonintrusiveModel.objects.values('status').annotate(dcount=Avg('total_mins'))
    return render(request,'user/categoryanalysis_chart.html',{'objects':chart,'chart_type':chart_type})